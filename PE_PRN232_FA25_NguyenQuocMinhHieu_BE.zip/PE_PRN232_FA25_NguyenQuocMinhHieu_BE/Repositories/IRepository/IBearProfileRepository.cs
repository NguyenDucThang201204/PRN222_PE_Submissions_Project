﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repositories.Models;
using Repositories.DTOs;


namespace Repositories.IRepository
{
    public interface IBearProfileRepository
    {
        Task<IEnumerable<BearProfile>> GetAllAsync();

        Task<BearProfile?> GetByIdAsync(int id);

        Task<BearProfile> CreateAsync(BearProfileDto dto);

        Task<bool> UpdateAsync(int id, BearProfileDto dto);

        Task<bool> DeleteAsync(int id);

        Task<IEnumerable<BearProfile>> SearchAsync(string? BearName, double? weight);
    }
}
