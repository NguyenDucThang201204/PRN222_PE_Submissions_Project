﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.DTOs
{
    public class BearProfileDto
    {
        public int BearProfileId { get; set; }

        [Required]
        public int BearTypeId { get; set; }

        [Required(ErrorMessage = "Bear name is required")]
        [RegularExpression(
            @"^([A-Z0-9][a-zA-Z0-9]*\s)([A-Z0-9][a-zA-Z0-9]*)$",
            ErrorMessage = "Bear name must have two words, each starting with an uppercase letter or number, followed by letters or digits."
        )]
        public string BearName { get; set; } = null!;

        [Range(200.01, double.MaxValue, ErrorMessage = "Weight must be greater than 200")]
        public double Weight { get; set; }

        [Required]
        public string Characteristics { get; set; } = null!;

        [Required]
        public string CareNeeds { get; set; } = null!;

        public DateTime ModifiedDate { get; set; } = DateTime.Now;
    }
}
