﻿using Microsoft.EntityFrameworkCore;
using Repositories.DTOs;
using Repositories.IRepository;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Repository
{
    public class BearProfileRepository : IBearProfileRepository
    {
        private readonly Fa25bearDbContext _context;

        public BearProfileRepository(Fa25bearDbContext context) {

            _context = context;

        }

        public async Task<BearProfile> CreateAsync(BearProfileDto dto)
        {
            var entity = new BearProfile
            {
                BearTypeId = dto.BearTypeId,
                BearName = dto.BearName,
                Weight = dto.Weight,
                Characteristics = dto.Characteristics,
                CareNeeds = dto.CareNeeds,
                ModifiedDate = DateTime.Now
            };

            _context.BearProfiles.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var existing = await _context.BearProfiles.FindAsync(id);
            if (existing == null)
                return false;

            _context.BearProfiles.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<BearProfile>> GetAllAsync()
        {
            return await _context.BearProfiles.Include(Be => Be.BearType).ToListAsync();
              
        }

        public async Task<BearProfile?> GetByIdAsync(int id)
        {
            return await _context.BearProfiles
                .Include(lp => lp.BearType)
                .FirstOrDefaultAsync(lp => lp.BearProfileId == id);
        }

        public async Task<IEnumerable<BearProfile>> SearchAsync(string? BearName, double? weight)
        {
            var query = _context.BearProfiles.AsQueryable();

            if (!string.IsNullOrWhiteSpace(BearName))
            {
                query = query.Where(lp => lp.BearName.Contains(BearName));
            }

            if (weight.HasValue)
            {
                query = query.Where(lp => lp.Weight == weight.Value);
            }

            return await query
                .Include(lp => lp.BearType)
                .ToListAsync();
        }

        public async Task<bool> UpdateAsync(int id, BearProfileDto dto)
        {
            var existing = await _context.BearProfiles.FindAsync(id);
            if (existing == null)
                return false;

            existing.BearTypeId = dto.BearTypeId;
            existing.BearName = dto.BearName;
            existing.Weight = dto.Weight;
            existing.Characteristics = dto.Characteristics;
            existing.CareNeeds = dto.CareNeeds;
            existing.ModifiedDate = DateTime.Now;

            _context.BearProfiles.Update(existing);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
