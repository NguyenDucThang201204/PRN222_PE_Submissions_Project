﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using System.Text.RegularExpressions;
using Services.IService;
using Repositories.DTOs;

namespace PE_PRN232_FA25_NguyenQuocMinhHieu_BE.Controllers
{
    public class BearProfileController : Controller
    {
        private readonly IBearProfileService _bearProfileService;

        public BearProfileController(IBearProfileService bearProfileService)
        {
            _bearProfileService = bearProfileService;
        }

        [HttpGet]
        [Authorize(Policy = "ReadOnly")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var profiles = await _bearProfileService.GetAllAsync();
                return Ok(profiles);
            }
            catch
            {
                return StatusCode(500, new { errorCode = "HB50001", message = "Internal server error" });
            }
        }

        [HttpGet("{id}")]
        [Authorize(Policy = "ReadOnly")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var profile = await _bearProfileService.GetByIdAsync(id);
                if (profile == null)
                    return NotFound(new { errorCode = "HB40401", message = "LeopardProfile not found" });

                return Ok(profile);
            }
            catch
            {
                return StatusCode(500, new { errorCode = "HB50001", message = "Internal server error" });
            }
        }

        [HttpPost]
        [Authorize(Policy = "FullAccess")]
        public async Task<IActionResult> Create([FromBody] BearProfileDto dto)
        {
            if (dto == null)
                return BadRequest(new { errorCode = "HB40001", message = "Request body is required" });

            var regex = new Regex(@"^([A-Z0-9][a-zA-Z0-9]*\s)*([A-Z0-9][a-zA-Z0-9]*)$");
            if (!regex.IsMatch(dto.BearName ?? ""))
                return BadRequest(new { errorCode = "HB40001", message = "Invalid LeopardName format" });

            if (dto.Weight <= 15)
                return BadRequest(new { errorCode = "HB40001", message = "Weight must be greater than 15" });

            try
            {
                var newProfile = await _bearProfileService.CreateAsync(dto);
                return CreatedAtAction(nameof(GetById), new { id = newProfile.BearProfileId }, newProfile);
            }
            catch
            {
                return StatusCode(500, new { errorCode = "HB50001", message = "Internal server error" });
            }
        }

        [HttpPut("{id}")]
        [Authorize(Policy = "FullAccess")]
        public async Task<IActionResult> Update(int id, [FromBody] BearProfileDto dto)
        {
            if (dto == null)
                return BadRequest(new { errorCode = "HB40001", message = "Request body is required" });

            try
            {
                var updated = await _bearProfileService.UpdateAsync(id, dto);
                if (!updated)
                    return NotFound(new { errorCode = "HB40401", message = "LeopardProfile not found" });

                return Ok(new { message = "LeopardProfile updated successfully" });
            }
            catch
            {
                return StatusCode(500, new { errorCode = "HB50001", message = "Internal server error" });
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Policy = "FullAccess")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var deleted = await _bearProfileService.DeleteAsync(id);
                if (!deleted)
                    return NotFound(new { errorCode = "HB40401", message = "LeopardProfile not found" });

                return Ok(new { message = "LeopardProfile deleted successfully" });
            }
            catch
            {
                return StatusCode(500, new { errorCode = "HB50001", message = "Internal server error" });
            }
        }

        [HttpGet("search")]
        [Authorize(Policy = "ReadOnly")]
        [EnableQuery]
        public async Task<IActionResult> Search([FromQuery] string? LeopardName, [FromQuery] double? Weight)
        {
            try
            {
                var profiles = await _bearProfileService.GetAllAsync();
                var query = profiles.AsQueryable();

                if (!string.IsNullOrEmpty(LeopardName))
                    query = query.Where(l => l.BearName.Contains(LeopardName));

                if (Weight.HasValue)
                    query = query.Where(l => l.Weight == Weight.Value);

                return Ok(query);
            }
            catch
            {
                return StatusCode(500, new { errorCode = "HB50001", message = "Internal server error" });
            }
        }


    }
}

