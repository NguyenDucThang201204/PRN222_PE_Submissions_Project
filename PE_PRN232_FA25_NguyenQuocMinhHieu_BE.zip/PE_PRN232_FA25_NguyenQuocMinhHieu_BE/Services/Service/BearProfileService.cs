﻿using Repositories.DTOs;
using Repositories.Models;
using Services.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repositories.IRepository;


namespace Services.Service
{
    public class BearProfileService : IBearProfileService
    {
        private readonly IBearProfileRepository _repository;

        public BearProfileService(IBearProfileRepository repository)
        {
            _repository = repository;
        }

        public Task<BearProfile> CreateAsync(BearProfileDto dto) => _repository.CreateAsync(dto);


        public Task<bool> DeleteAsync(int id) => _repository.DeleteAsync(id);


        public Task<IEnumerable<BearProfile>> GetAllAsync() => _repository.GetAllAsync();


        public Task<BearProfile?> GetByIdAsync(int id) => _repository.GetByIdAsync(id);


        public Task<IEnumerable<BearProfile>> SearchAsync(string? BearName, double? weight) => _repository.SearchAsync(BearName, weight);


        public Task<bool> UpdateAsync(int id, BearProfileDto dto) => _repository.UpdateAsync(id, dto);

    }
}
