﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repositories.DTOs;
using Repositories.Models;

namespace Services.IService
{
    public interface IBearProfileService
    {
        Task<IEnumerable<BearProfile>> GetAllAsync();

        Task<BearProfile?> GetByIdAsync(int id);

        Task<BearProfile> CreateAsync(BearProfileDto dto);

        Task<bool> UpdateAsync(int id, BearProfileDto dto);

        Task<bool> DeleteAsync(int id);

        Task<IEnumerable<BearProfile>> SearchAsync(string? BearName, double? weight);
    }
}
