﻿using Repositories.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.IService
{
    public interface IAccountService
    {
        AuthResponse Authenticate(string email, string password);
    }
}
