﻿using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class BearTypeRepository : GenericRepository<BearType>
    {
        public BearTypeRepository() { }
        public BearTypeRepository(Fa25bearDbContext context) => _context = context;
    }
}
