﻿using System;
using System.Collections.Generic;

namespace Repositories.Models;

public partial class BearProfile
{
    public int BearProfileId { get; set; }

    public int? BearTypeId { get; set; }

    public string BearlName { get; set; } = null!;

    public string? BearWeight { get; set; }

    public string? Characteristics { get; set; }

    public bool? CareNeeds { get; set; }

    public DateOnly? ModifiedDate { get; set; }

    public virtual BearType? BearType { get; set; }
}
