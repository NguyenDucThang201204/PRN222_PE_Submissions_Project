﻿using System;
using System.Collections.Generic;

namespace Repositories.Models;

public partial class BearType
{
    public int BearTypeId { get; set; }

    public string BearName { get; set; } = null!;

    public string? Origin { get; set; }

    public string? Descriptioin { get; set; }

    public virtual ICollection<BearProfile> BearProfiles { get; set; } = new List<BearProfile>();
}
