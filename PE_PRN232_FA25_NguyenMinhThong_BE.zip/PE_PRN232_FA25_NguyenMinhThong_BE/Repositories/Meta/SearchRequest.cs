﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Meta
{
    public class SearchRequest
    {
        public int? CurrentPage { get; set; }
        public int? PageSize { get; set; }
    }

    public class ItemSearchRequest : SearchRequest
    {
        public string? BearName { get; set; }
        public string? Material { get; set; }
        public string? BearTypeName { get; set; }
    }

}
