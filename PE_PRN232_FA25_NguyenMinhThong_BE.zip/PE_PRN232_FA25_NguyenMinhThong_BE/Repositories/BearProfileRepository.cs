﻿using Microsoft.EntityFrameworkCore;
using Repositories.Meta;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class BearProfileRepository : GenericRepository<BearProfile>
    {
        public BearProfileRepository() { }

        public BearProfileRepository(Fa25bearDbContext context) => _context = context;

        public async Task<List<BearProfile>> GetAllAsync()
        {
            return await _context.Set<BearProfile>()
                .Include(hb => hb.BearType)
                .ToListAsync();
        }

        public async Task<PaginationResult<BearProfile>> GetAllPagingAsync(int pageSize, int currentPage)
        {
            var totalItems = await _context.BearProfiles.CountAsync();
            var totalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            if (currentPage < 1)
                currentPage = 1;

            if (currentPage > totalPages)
                currentPage = totalPages;

            var items = await _context.Set<BearProfile>()
                .Include(hb => hb.BearType)
                .ToListAsync();

            items = items
                .Skip((currentPage - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            return new PaginationResult<BearProfile>
            {
                CurrentPage = currentPage,
                TotalItems = totalItems,
                TotalPages = totalPages,
                Items = items,
                PageSize = pageSize
            } ?? new PaginationResult<BearProfile>
            {
                Items = []
            };
        }

        public async Task<BearProfile?> GetByIdAsync(int id)
        {
            var item = await _context.BearProfiles
                .Include(p => p.BearType)
                .FirstOrDefaultAsync(p => p.BearProfileId == id);
            return item;
        }

        public async Task<PaginationResult<BearProfile>> SearchPaging(string? bearName, string? BearTypeName, int pageSize, int currentPage)
        {
            var totalItems = await _context.BearProfiles.CountAsync();
            var totalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            if (currentPage < 1)
                currentPage = 1;

            if (currentPage > totalPages)
                currentPage = totalPages;

            var items = await Search(bearName, BearTypeName);

            items = items
                .Skip((currentPage - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            return new PaginationResult<BearProfile>
            {
                CurrentPage = currentPage,
                TotalItems = totalItems,
                TotalPages = totalPages,
                Items = items,
                PageSize = pageSize
            } ?? new PaginationResult<BearProfile>
            {
                Items = []
            };
        }

        public async Task<List<BearProfile>> Search(string? bearName, string? BearTypeName)
        {
            var items = await _context.BearProfiles
                .Include(hb => hb.BearType)
                .Where(hb => (hb.BearlName.Contains(bearName) || string.IsNullOrEmpty(bearName))
                            && (hb.BearType.BearName.Contains(BearTypeName) || string.IsNullOrEmpty(BearTypeName)))
                .ToListAsync();
            return items ?? [];
        }

        public async Task<List<BearProfile>> SearchByBearName(string? bearName)
        {
            var items = await _context.BearProfiles
                .Include(hb => hb.BearType)
                .Where(hb => (hb.BearlName.Contains(bearName) || string.IsNullOrEmpty(bearName))
                            )
                .ToListAsync();
            return items ?? [];
        }
    }
}
