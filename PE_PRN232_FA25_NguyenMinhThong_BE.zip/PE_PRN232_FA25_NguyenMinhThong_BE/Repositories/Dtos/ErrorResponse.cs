﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Dtos
{
    public class ErrorResponse
    {
        public string ErrorCode { get; set; }
        public string Message { get; set; }

        public ErrorResponse(string errorCode, string message)
        {
            ErrorCode = errorCode;
            Message = message;
        }
    }

    public static class ErrorCodes
    {
        public const string HB40001 = "HB40001";  // Missing/invalid input (400)
        public const string HB40101 = "HB40101";  // Token missing/invalid (401)
        public const string HB40301 = "HB40301";  // Permission denied (403)
        public const string HB40401 = "HB40401";  // Resource not found (404)
        public const string HB50001 = "HB50001";  // Internal server error (500)
    }
}
