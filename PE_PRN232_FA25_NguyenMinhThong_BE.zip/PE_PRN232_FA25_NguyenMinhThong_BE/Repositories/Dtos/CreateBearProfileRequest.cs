﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Dtos
{
    public class CreateBearProfileRequest
    {
        [Required(ErrorMessage = "Bear Id is required.")]
        public int BearId { get; set; }

        public string BearlName { get; set; }

        public string? BearWeight { get; set; }

        public string? Characteristics { get; set; }

        public bool? CareNeeds { get; set; }

        public DateOnly? ModifiedDate { get; set; }
    }
}
