﻿using Repositories;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Implements
{
    public interface IBearTypeSevice
    {
        Task<List<BearType>> GetAll();
    }
    public class BearTypeService : IBearTypeSevice
    {
        private readonly BearTypeRepository _repository;

        public BearTypeService() => _repository = new BearTypeRepository();

        public async Task<List<BearType>> GetAll()
        {
            return await _repository.GetAllAsync();
        }
    }
}
