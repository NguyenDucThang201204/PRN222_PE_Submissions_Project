﻿using Repositories;
using Repositories.Dtos;
using Repositories.Meta;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Implements
{
    public interface IBearProfileService
    {
        Task<List<BearProfile>> GetAll();

        Task<BearProfile?> GetByIdAsync(int id);

        Task<PaginationResult<BearProfile>> GetAllPaging(SearchRequest request);

        Task<List<BearProfile>> Search(ItemSearchRequest request);

        Task<List<BearProfile>> SearchByBearName(string? BearlName);

        Task<PaginationResult<BearProfile>> SearchPaging(ItemSearchRequest request);

        Task<int> CreateAsync(CreateBearProfileRequest request);

        Task<bool> DeleteAsync(int id);

        Task<int> UpdateAsync(int id, CreateBearProfileRequest request);
        public class BearProfileService : IBearProfileService
        {
            private BearProfileRepository _repository;

            public BearProfileService() => _repository = new BearProfileRepository();

            public async Task<int> CreateAsync(CreateBearProfileRequest request)
            {
                var BearProfile = new BearProfile
                {
                    BearProfileId = request.BearId,
                    BearlName = request.BearlName,
                    BearWeight = request.BearWeight,
                    Characteristics = request.Characteristics,
                    CareNeeds = request.CareNeeds,
                    ModifiedDate = request.ModifiedDate
                };
                return await _repository.CreateAsync(BearProfile);
            }

            public async Task<bool> DeleteAsync(int id)
            {
                var BearProfile = await _repository.GetByIdAsync(id);
                if (BearProfile == null) return false;

                return await _repository.RemoveAsync(BearProfile);
            }

            public async Task<List<BearProfile>> GetAll()
            {
                return await _repository.GetAllAsync();
            }

            public async Task<BearProfile?> GetByIdAsync(int id)
            {
                return await _repository.GetByIdAsync(id);
            }

            public async Task<PaginationResult<BearProfile>> GetAllPaging(SearchRequest request)
            {
                return await _repository.GetAllPagingAsync(request.PageSize.GetValueOrDefault(), request.CurrentPage.GetValueOrDefault());
            }

            public async Task<List<BearProfile>> Search(ItemSearchRequest request)
            {
                return await _repository.Search(request.BearName, request.BearName);
            }

            public async Task<List<BearProfile>> SearchByBearName(string? BearlName)
            {
                return await _repository.SearchByBearName(BearlName);
            }

            public async Task<PaginationResult<BearProfile>> SearchPaging(ItemSearchRequest request)
            {
                return await _repository.SearchPaging(request.BearName, request.BearName,
                    request.PageSize.GetValueOrDefault(),
                    request.CurrentPage.GetValueOrDefault());
            }

            public async Task<int> UpdateAsync(int id, CreateBearProfileRequest request)
            {
                var BearProfile = await _repository.GetByIdAsync(id);

                if (BearProfile == null) return 0;

                BearProfile.BearProfileId = request.BearId;
                BearProfile.BearlName = request.BearlName;
                BearProfile.BearWeight = request.BearWeight;
                BearProfile.Characteristics = request.Characteristics;
                BearProfile.CareNeeds = request.CareNeeds;
                BearProfile.ModifiedDate = request.ModifiedDate;

                return await _repository.UpdateAsync(BearProfile);
            }
        }
    }
}
