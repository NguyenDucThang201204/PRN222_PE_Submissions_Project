﻿using Repositories;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Implements
{
    public interface IBearAccountService
    {
        Task<BearAccount?> GetUserAccount(string Email, string password);
    }
    public class BearAccountService : IBearAccountService
    {
        private readonly BearAccountRepository _repository;

        public BearAccountService() => _repository = new BearAccountRepository();

        public async Task<BearAccount?> GetUserAccount(string email, string password)
        {
            var user = await _repository.GetByUsernameAsync(email, password);
            return user;
        }
    }
}
