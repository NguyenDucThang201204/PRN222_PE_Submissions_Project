﻿using Repositories.Dtos;
using System.Net;
using System.Text.Json;

namespace PE_PRN232_FA25_NguyenMinhThong_BE.Middleware
{
    public class CustomErrorMiddleware
    {
        private readonly RequestDelegate _next;

        public CustomErrorMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);

                // Handle 401 Unauthorized
                if (context.Response.StatusCode == (int)HttpStatusCode.Unauthorized)
                {
                    await HandleUnauthorizedAsync(context);
                }
                // Handle 403 Forbidden
                else if (context.Response.StatusCode == (int)HttpStatusCode.Forbidden)
                {
                    await HandleForbiddenAsync(context);
                }
            }
            catch (Exception)
            {
                await HandleInternalServerErrorAsync(context);
            }
        }

        private static async Task HandleUnauthorizedAsync(HttpContext context)
        {
            if (!context.Response.HasStarted && context.Response.ContentLength == null)
            {
                context.Response.ContentType = "application/json";
                var errorResponse = new ErrorResponse(ErrorCodes.HB40101, "Token missing or invalid");
                var json = JsonSerializer.Serialize(errorResponse, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });
                await context.Response.WriteAsync(json);
            }
        }

        private static async Task HandleForbiddenAsync(HttpContext context)
        {
            if (!context.Response.HasStarted && context.Response.ContentLength == null)
            {
                context.Response.ContentType = "application/json";
                var errorResponse = new ErrorResponse(ErrorCodes.HB40301, "Permission denied");
                var json = JsonSerializer.Serialize(errorResponse, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });
                await context.Response.WriteAsync(json);
            }
        }

        private static async Task HandleInternalServerErrorAsync(HttpContext context)
        {
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.Response.ContentType = "application/json";

            var errorResponse = new ErrorResponse(ErrorCodes.HB50001, "Internal server error");
            var json = JsonSerializer.Serialize(errorResponse, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });
            await context.Response.WriteAsync(json);
        }
    }
}
