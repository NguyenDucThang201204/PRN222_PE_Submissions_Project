﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Repositories.Dtos;
using Services.Implements;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace PE_PRN232_FA25_NguyenMinhThong_BE.Controllers
{

        [ApiController]
        [Route("api/[controller]")]
        public class BearAccountController : ControllerBase
        {
            private readonly IBearAccountService _userService;
            private readonly IConfiguration _configuration;

            public BearAccountController(IBearAccountService userService, IConfiguration configuration)
            {
                _userService = userService;
                _configuration = configuration;
            }

            [HttpPost]
            public async Task<IActionResult> Login([FromBody] LoginRequest request)
            {
                try
                {
                    if (!ModelState.IsValid)
                    {
                        var firstError = ModelState.Values.FirstOrDefault()?.Errors.FirstOrDefault()?.ErrorMessage;
                        return BadRequest(new ErrorResponse(ErrorCodes.HB40001, firstError ?? "Invalid input"));
                    }

                    var user = await _userService.GetUserAccount(request.Email, request.Password);
                    if (user == null)
                    {
                        return Unauthorized(new ErrorResponse(ErrorCodes.HB40101, "Invalid email or password"));
                    }

                    var roleMapping = new Dictionary<int, string>
                {
                    { 1, "Admin" },
                    { 2, "Manager" },
                    { 3, "Staff" },
                    { 4, "Member" }
                };

                    if (!roleMapping.ContainsKey(user.Role ?? 0))
                    {
                        return Unauthorized(new ErrorResponse(ErrorCodes.HB40101, "Access denied for this role"));
                    }

                    var roleName = roleMapping[user.Role.Value];
                    var token = GenerateJwtToken(user.Email, roleName);

                    return Ok(new LoginResponse(token, roleName));
                }
                catch (Exception ex)
                {
                    return StatusCode(500, new ErrorResponse(ErrorCodes.HB50001, "Internal server error"));
                }
            }

            private string GenerateJwtToken(string email, string role)
            {
                var jwtKey = _configuration["Jwt:Key"];
                var jwtIssuer = _configuration["Jwt:Issuer"];
                var jwtAudience = _configuration["Jwt:Audience"];

                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

                var claims = new[]
                {
                new Claim(JwtRegisteredClaimNames.Email, email),
                new Claim(ClaimTypes.Role, role),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

                var token = new JwtSecurityToken(
                    issuer: jwtIssuer,
                    audience: jwtAudience,
                    claims: claims,
                    expires: DateTime.Now.AddMinutes(60),
                    signingCredentials: credentials
                );

                return new JwtSecurityTokenHandler().WriteToken(token);
            }
        }
    }

