﻿using Microsoft.AspNetCore.Mvc;
using Services.Implements;

namespace PE_PRN232_FA25_NguyenMinhThong_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BearTypeServiceController : ControllerBase
    {
        private readonly IBearTypeSevice _service;

        public BearTypeServiceController(IBearTypeSevice service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var items = await _service.GetAll();
            return Ok(items);
        }
    }
}
