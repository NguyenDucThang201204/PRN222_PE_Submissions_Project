﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Repositories.Dtos;
using Services.Implements;

namespace PE_PRN232_FA25_NguyenMinhThong_BE.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class BearProfileController : Controller
    {

            private readonly IBearProfileService _bearproService;

            public BearProfileController(IBearProfileService bearproService)
            {
                _bearproService = bearproService;
            }

            [HttpGet]
            [Authorize(Roles = "Admin,Manager,Staff,Member")]
            public async Task<IActionResult> GetAllBearProfiles()
            {
                try
                {
                    var BearProfiles = await _bearproService.GetAll();
                    return Ok(BearProfiles);
                }
                catch (Exception ex)
                {
                    return StatusCode(500, new ErrorResponse(ErrorCodes.HB50001, "Internal server error"));
                }
            }

            [HttpGet("{id}")]
            [Authorize(Roles = "Admin,Manager,Staff,Member")]
            public async Task<IActionResult> GetBearProfileById(int id)
            {
                try
                {
                    var BearProfile = await _bearproService.GetByIdAsync(id);
                    if (BearProfile == null)
                    {
                        return NotFound(new ErrorResponse(ErrorCodes.HB40401, "BearProfile not found"));
                    }
                    return Ok(BearProfile);
                }
                catch (Exception ex)
                {
                    return StatusCode(500, new ErrorResponse(ErrorCodes.HB50001, "Internal server error"));
                }
            }

            [HttpPost]
            [Authorize(Roles = "Admin,Manager")]
            public async Task<IActionResult> CreateBearProfile([FromBody] CreateBearProfileRequest request)
            {
                try
                {
                    if (!ModelState.IsValid)
                    {
                        var firstError = ModelState.Values.FirstOrDefault()?.Errors.FirstOrDefault()?.ErrorMessage;
                        return BadRequest(new ErrorResponse(ErrorCodes.HB40001, firstError ?? "Invalid input"));
                    }

                    var BearProfileId = await _bearproService.CreateAsync(request);
                    if (BearProfileId > 0)
                    {
                        return StatusCode(201, new { id = BearProfileId });
                    }
                    else
                    {
                        return BadRequest(new ErrorResponse(ErrorCodes.HB40001, "Failed to create BearProfile"));
                    }
                }
                catch (Exception ex)
                {
                    return StatusCode(500, new ErrorResponse(ErrorCodes.HB50001, "Internal server error"));
                }
            }

            [HttpPut("{id}")]
            [Authorize(Roles = "Admin,Manager")]
            public async Task<IActionResult> UpdateBearProfile(int id, [FromBody] CreateBearProfileRequest request)
            {
                try
                {
                    if (!ModelState.IsValid)
                    {
                        var firstError = ModelState.Values.FirstOrDefault()?.Errors.FirstOrDefault()?.ErrorMessage;
                        return BadRequest(new ErrorResponse(ErrorCodes.HB40001, firstError ?? "Invalid input"));
                    }

                    var existingBearProfile = await _bearproService.GetByIdAsync(id);
                    if (existingBearProfile == null)
                    {
                        return NotFound(new ErrorResponse(ErrorCodes.HB40401, "BearProfile not found"));
                    }

                    var result = await _bearproService.UpdateAsync(id, request);
                    if (result > 0)
                    {
                        var updatedBearProfile = await _bearproService.GetByIdAsync(id);
                        return Ok(updatedBearProfile);
                    }
                    else
                    {
                        return BadRequest(new ErrorResponse(ErrorCodes.HB40001, "Failed to update BearProfile"));
                    }
                }
                catch (Exception ex)
                {
                    return StatusCode(500, new ErrorResponse(ErrorCodes.HB50001, "Internal server error"));
                }
            }

            [HttpDelete("{id}")]
            [Authorize(Roles = "Admin,Manager")]
            public async Task<IActionResult> DeleteBearProfile(int id)
            {
                try
                {
                    var existingBearProfile = await _bearproService.GetByIdAsync(id);
                    if (existingBearProfile == null)
                    {
                        return NotFound(new ErrorResponse(ErrorCodes.HB40401, "BearProfile not found"));
                    }

                    var result = await _bearproService.DeleteAsync(id);
                    if (result)
                    {
                        return Ok(new { message = "BearProfile deleted successfully" });
                    }
                    else
                    {
                        return BadRequest(new ErrorResponse(ErrorCodes.HB40001, "Failed to delete BearProfile"));
                    }
                }
                catch (Exception ex)
                {
                    return StatusCode(500, new ErrorResponse(ErrorCodes.HB50001, "Internal server error"));
                }
            }

            [HttpGet("search")]
            [Authorize(Roles = "Admin,Manager,Staff,Member")]
            public async Task<IActionResult> SearchBearProfiles([FromQuery] string? BearlName, [FromQuery] string? BearWeight)
            {
                try
                {
                    var BearProfiles = await _bearproService.SearchByBearName(BearlName);

                    var groupedResults = BearProfiles
                        .GroupBy(h => h.BearType?.BearName ?? "Unknown")
                        .Select(g => new
                        {
                            BearTypeName = g.Key,
                            BearProfiles = g.ToList()
                        })
                        .ToList();

                    return Ok(groupedResults);
                }
                catch (Exception ex)
                {
                    return StatusCode(500, new ErrorResponse(ErrorCodes.HB50001, "Internal server error"));
                }
            }
        }
    }