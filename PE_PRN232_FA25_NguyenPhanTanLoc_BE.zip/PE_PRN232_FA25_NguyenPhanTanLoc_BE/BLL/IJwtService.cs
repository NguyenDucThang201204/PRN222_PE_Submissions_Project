﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public interface IJwtService
    {
        string GenerateRefreshToken();
        string GenerateToken(string memberId, string email, IList<string> roles = null);
        ClaimsPrincipal ValidateToken(string token);
    }
}
