﻿using DAL.Models.Dtos;
using DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepo _authRepo;
        private readonly IJwtService _jwtService;
        public AuthService(IAuthRepo authRepo, IJwtService jwtService)
        {
            _authRepo = authRepo;
            _jwtService = jwtService;
        }

        public async Task<LoginResponse> Authenticate(LoginRequest request)
        {
            var account = await _authRepo.Login(request.username, request.password);
            if (account == null)
            {
                return null;
            }

            string roleName = account.RoleId switch
            {
                1 => "Admin",
                2 => "Manager",
                3 => "Staff",
                4 => "Member",
                _ => "Guest"
            };


            var role = new List<string>();
            if (account.RoleId != 0)
            {
                role.Add(roleName);
                // role.Add(account.Role.ToString());
            }
            var token = _jwtService.GenerateToken(
                account.AccountId.ToString(),
                account.Email ?? string.Empty,
                role
                );

            var refresh = _jwtService.GenerateRefreshToken();
            return new LoginResponse
            {
                Token = token,
                Role = roleName
                //Role = account.Role != 0 ? account.Role.ToString() : "0"
            };

        }
    }
}
