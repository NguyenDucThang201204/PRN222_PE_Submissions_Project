﻿using DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DAO
{
    public class AuthDAO
    {
        private readonly FA25BearContext _dbContext;
        public AuthDAO(FA25BearContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BearAccount> LoginAsync(string email, string password)
        {
            return await _dbContext.BearAccounts.Where(x => x.Email == email && x.Password == password).FirstOrDefaultAsync();
        }
    }
}
