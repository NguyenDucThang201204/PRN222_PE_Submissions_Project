﻿using DAL.DAO;
using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repository
{
    public class AuthRepo : IAuthRepo
    {
        private readonly AuthDAO _authDAO;
        public AuthRepo(AuthDAO authDAO)
        {
            _authDAO = authDAO;
        }

        public async Task<BearAccount> Login(string email, string password)
        => await _authDAO.LoginAsync(email, password);
    }
}
