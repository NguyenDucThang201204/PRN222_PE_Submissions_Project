﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models.Dtos
{
    public class ErrorResponseDTO
    {
        public string ErrorCode { get; set; } = null!;
        public string Message { get; set; } = null!;
        public string? Details { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }
}
