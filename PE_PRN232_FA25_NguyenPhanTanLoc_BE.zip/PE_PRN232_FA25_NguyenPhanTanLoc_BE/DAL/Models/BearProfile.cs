﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    public class BearProfile
    {
        public int BearProfileId { get; set; }

        public int? BearTypeId { get; set; }

        public string BearName { get; set; } = null!;

        public decimal? BearWeight { get; set; }

        public string? Characteristics { get; set; }

        public string? CareNeeds { get; set; }

        public DateOnly? ReleaseDate { get; set; }

        public virtual BearType? BearType { get; set; }
    }
}
