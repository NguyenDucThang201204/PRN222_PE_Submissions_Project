﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models.Error
{
    public static class ErrorCodes
    {
        // 400 - Bad Request
        public const string HB40001 = "HB40001";

        // 401 - Unauthorized
        public const string HB40101 = "HB40101";

        // 403 - Forbidden
        public const string HB40301 = "HB40301";

        // 404 - Not Found
        public const string HB40401 = "HB40401";

        // 500 - Internal Server Error
        public const string HB50001 = "HB50001";

        // Error messages
        public static readonly Dictionary<string, (int StatusCode, string Message)> ErrorMessages = new()
        {
            { HB40001, (400, "Missing/invalid input") },
            { HB40101, (401, "Token missing/invalid") },
            { HB40301, (403, "Permission denied") },
            { HB40401, (404, "Resource not found") },
            { HB50001, (500, "Internal server error") }
        };

        public static (int StatusCode, string Message) GetError(string errorCode)
        {
            return ErrorMessages.TryGetValue(errorCode, out var error)
                ? error
                : (500, "Unknown error");
        }
    }
}
