﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DAL.Migrations
{
    /// <inheritdoc />
    public partial class AddFirst : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BearAccounts",
                columns: table => new
                {
                    AccountID = table.Column<int>(type: "int", nullable: false),
                    Username = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Password = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: true),
                    Phone = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__BearAc__349DA586F4248147", x => x.AccountID);
                });

            migrationBuilder.CreateTable(
                name: "BearType",
                columns: table => new
                {
                    BearTypeId = table.Column<int>(type: "int", nullable: false),
                    BearTypeName = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Origin = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__BearType__DAD4F3BE01DA5472", x => x.BearTypeId);
                });

            migrationBuilder.CreateTable(
                name: "BearProfile",
                columns: table => new
                {
                    BearProfileId = table.Column<int>(type: "int", nullable: false),
                    BearTypeId = table.Column<int>(type: "int", nullable: true),
                    BearName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    BearWeight = table.Column<decimal>(type: "decimal(10,2)", nullable: true),
                    Characteristics = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    CareNeeds = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    ReleaseDate = table.Column<DateOnly>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__BearProfile__785BD69F8366B760", x => x.BearProfileId);
                    table.ForeignKey(
                        name: "fk_BearProfile_BearType",
                        column: x => x.BearTypeId,
                        principalTable: "BearType",
                        principalColumn: "BearTypeId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_BearProfile_BearTypeId",
                table: "BearProfile",
                column: "BearTypeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BearAccounts");

            migrationBuilder.DropTable(
                name: "BearProfile");

            migrationBuilder.DropTable(
                name: "BearType");
        }
    }
}
