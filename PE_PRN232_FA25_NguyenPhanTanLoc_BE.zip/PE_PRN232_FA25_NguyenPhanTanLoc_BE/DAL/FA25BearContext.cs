﻿using DAL.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public partial class FA25BearContext : DbContext
    {
        public FA25BearContext()
        {
        }

        public FA25BearContext(DbContextOptions<FA25BearContext> options)
         : base(options)
        {
        }

        public DbSet<BearAccount> BearAccounts { get; set; }
        public DbSet<BearProfile> BearProfiles { get; set; }

        public DbSet<BearType> BearTypes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
           => optionsBuilder.UseSqlServer(GetConnectionString());

        private string GetConnectionString()
        {
            IConfiguration configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", true, true).Build();
            return configuration["ConnectionStrings:DefaultConnection"];
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BearType>(entity =>
            {
                entity.HasKey(e => e.BearTypeId).HasName("PK__BearType__DAD4F3BE01DA5472");

                entity.ToTable("BearType");

                entity.Property(e => e.BearTypeId)
                    .ValueGeneratedNever()
                    .HasColumnName("BearTypeId");
                entity.Property(e => e.BearTypeName)
                    .HasMaxLength(255)
                    .IsUnicode(false);
                entity.Property(e => e.Origin)
                    .HasMaxLength(100)
                    .IsUnicode(false);
                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<BearProfile>(entity =>
            {
                entity.HasKey(e => e.BearProfileId).HasName("PK__BearProfile__785BD69F8366B760");

                entity.ToTable("BearProfile");

                entity.Property(e => e.BearProfileId)
                    .ValueGeneratedNever()
                    .HasColumnName("BearProfileId");
                entity.Property(e => e.BearTypeId).HasColumnName("BearTypeId");
                entity.Property(e => e.BearName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
                entity.Property(e => e.Characteristics)
                    .HasMaxLength(100)
                    .IsUnicode(false);
                entity.Property(e => e.CareNeeds)
                    .HasMaxLength(255)
                    .IsUnicode(false);
                entity.Property(e => e.BearWeight).HasColumnType("decimal(10, 2)");

                entity.HasOne(d => d.BearType).WithMany(p => p.BearProfiles)
                    .HasForeignKey(d => d.BearTypeId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_BearProfile_BearType");
            });

            modelBuilder.Entity<BearAccount>(entity =>
            {
                entity.HasKey(e => e.AccountId).HasName("PK__BearAc__349DA586F4248147");

                entity.Property(e => e.AccountId)
                    .ValueGeneratedNever()
                    .HasColumnName("AccountID");
                entity.Property(e => e.Email)
                    .HasMaxLength(255)
                    .IsUnicode(false);
                entity.Property(e => e.Password)
                    .HasMaxLength(255)
                    .IsUnicode(false);
                entity.Property(e => e.Username)
                    .HasMaxLength(100)
                    .IsUnicode(false);
                entity.Property(e => e.Phone)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
