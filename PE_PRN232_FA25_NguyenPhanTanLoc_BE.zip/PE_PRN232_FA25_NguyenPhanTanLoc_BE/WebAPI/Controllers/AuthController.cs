﻿using BLL;
using DAL.Models.Dtos;
using DAL.Models.Error;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("Accounts")]
    [ApiController]

    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }
        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            try
            {
                var response = await _authService.Authenticate(request);
                if (response == null)
                {
                    var error = ErrorCodes.GetError(ErrorCodes.HB40001);
                    return StatusCode(error.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40001,
                        Message = error.Message,
                        Details = "Invalid username or password"
                    });
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                var error = ErrorCodes.GetError(ErrorCodes.HB50001);
                return StatusCode(error.StatusCode, new ErrorResponseDTO
                {
                    ErrorCode = ErrorCodes.HB50001,
                    Message = error.Message,
                    Details = ex.Message
                });
            }
        }
    }
}
