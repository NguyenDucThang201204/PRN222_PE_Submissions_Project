
using BLL;
using DAL;
using DAL.DAO;
using DAL.Models.Dtos;
using DAL.Models.Error;
using DAL.Repository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

namespace WebAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();
            builder.Services.AddDbContext<FA25BearContext>(options =>
  options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


            builder.Services.AddScoped<AuthDAO>();
            builder.Services.AddScoped<IAuthService, AuthService>();
            builder.Services.AddScoped<IAuthRepo, AuthRepo>();
            builder.Services.AddScoped<IJwtService, JwtService>();

            builder.Services.AddSwaggerGen(c => {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Bear Management API v1", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. Enter your token here.",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.Http,
                    Scheme = "Bearer",
                    BearerFormat = "JWT"
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        {
            new OpenApiSecurityScheme {
                Reference = new OpenApiReference {
                    Type = ReferenceType.SecurityScheme,
                    Id = JwtBearerDefaults.AuthenticationScheme
                }
            },
            new List<string>()
        }
    });
            });

            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
   .AddJwtBearer(options => {
       options.TokenValidationParameters = new TokenValidationParameters
       {
           ValidateIssuer = true,
           ValidateAudience = true,
           ValidateLifetime = true,
           ValidateIssuerSigningKey = true,
           ValidIssuer = builder.Configuration["JWT:Issuer"],
           ValidAudience = builder.Configuration["JWT:Audience"],
           IssuerSigningKey = new SymmetricSecurityKey(
               Encoding.UTF8.GetBytes(builder.Configuration["JWT:SecretKey"]))
       };
       options.Events = new JwtBearerEvents
       {
           OnChallenge = context =>
           {
               // Skip the default behavior
               context.HandleResponse();

               context.Response.StatusCode = 401;
               context.Response.ContentType = "application/json";

               var error = ErrorCodes.GetError(ErrorCodes.HB40101);
               var errorResponse = new ErrorResponseDTO
               {
                   ErrorCode = ErrorCodes.HB40101,
                   Message = error.Message,
                   Details = "Authentication token is missing or invalid. Please login to get a valid token.",
                   Timestamp = DateTime.UtcNow
               };

               return context.Response.WriteAsJsonAsync(errorResponse);
           },
           OnForbidden = context =>
           {
               context.Response.StatusCode = 403;
               context.Response.ContentType = "application/json";

               var error = ErrorCodes.GetError(ErrorCodes.HB40301);
               var errorResponse = new ErrorResponseDTO
               {
                   ErrorCode = ErrorCodes.HB40301,
                   Message = error.Message,
                   Details = "You do not have permission to access this resource. Required role: Administrator or Moderator.",
                   Timestamp = DateTime.UtcNow
               };

               return context.Response.WriteAsJsonAsync(errorResponse);
           },
           OnAuthenticationFailed = context =>
           {
               if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
               {
                   context.Response.Headers.Add("Token-Expired", "true");
               }
               return Task.CompletedTask;
           }
       };
   });

            builder.Services.AddAuthorization(options =>
            {
                options.AddPolicy("RequireAdminRole", policy =>
                    policy.RequireRole("Admin")); // Full system access
                options.AddPolicy("RequireModeratorRole", policy =>
                    policy.RequireRole("Manager")); // Moderator operations 
                options.AddPolicy("RequireDeveloperRole", policy =>
                    policy.RequireRole("Staff")); // Developer access
                options.AddPolicy("RequireMemberRole", policy =>
                    policy.RequireRole("Member")); // Developer access
            });


            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI(options =>
                {
                    options.SwaggerEndpoint("/swagger/v1/swagger.json", "Bear management API v1");
                    options.RoutePrefix = string.Empty; // Sets Swagger UI at the app's root
                });
                app.MapOpenApi();
            }
            app.UseExceptionHandler(errorApp =>
            {
                errorApp.Run(async context =>
                {
                    context.Response.StatusCode = 500;
                    context.Response.ContentType = "application/json";

                    var error = ErrorCodes.GetError(ErrorCodes.HB50001);
                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();

                    var errorResponse = new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB50001,
                        Message = error.Message,
                        Details = contextFeature?.Error?.Message ?? "An unexpected error occurred",
                        Timestamp = DateTime.UtcNow
                    };

                    await context.Response.WriteAsJsonAsync(errorResponse);
                });
            });
            app.UseHttpsRedirection();
            app.UseAuthentication();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
