﻿using ItermService.DTO.Request;
using ItermService.DTO.Response;
using IternRepository.Models;
using IternRepository.UnitOfWork;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ItermService
{
    public class BearAccountService : IBearAccountService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _config;

        public BearAccountService(IUnitOfWork unitOfWork, IConfiguration config)
        {
            _unitOfWork = unitOfWork;
            _config = config;
        }

        public async Task<LoginResponseDto?> LoginAsync(LoginRequestDto loginRequest)
        {
            var account = await _unitOfWork.Accounts.GetByEmailAsync(loginRequest.userName);

            if (account == null || account.Password != loginRequest.password)
            {
                return null;
            }

            var roleName = GetRoleName(account.RoleId);
            if (roleName == "Other") return null;

            var token = GenerateJwtToken(account, roleName);

            return new LoginResponseDto
            {
                token = token,
                role = roleName
            };
        }

        private string GetRoleName(int? roleId)
        {
            return roleId switch
            {
                1 => "Admin",
                2 => "Manager",
                3 => "Staff",
                4 => "Member",
                _ => "Other"
            };
        }

        private string GenerateJwtToken(BearAccount account, string roleName)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
        new Claim(JwtRegisteredClaimNames.Sub, account.Email),
        new Claim(ClaimTypes.NameIdentifier, account.AccountId.ToString()),
        new Claim(ClaimTypes.Role, roleName)
    };

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
