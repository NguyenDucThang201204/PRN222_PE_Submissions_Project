﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItermService.DTO.Request
{
    public class LoginRequestDto
    {
        [Required, EmailAddress]
        public string userName { get; set; }
        [Required]
        public string password { get; set; }
    }
}
