﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItermService.DTO.Response
{
    public static class ApiErrorResponses
    {
        public static ErrorResponse InvalidInput { get; } = new()
        {
            errorCode = "HB40001",
            message = "Missing/invalid input"
        };

        public static ErrorResponse Unauthorized { get; } = new()
        {
            errorCode = "HB40101",
            message = "Token missing/invalid"
        };

        public static ErrorResponse Forbidden { get; } = new()
        {
            errorCode = "HB40301",
            message = "Permission denied"
        };

        public static ErrorResponse ResourceNotFound { get; } = new()
        {
            errorCode = "HB40401",
            message = "Resource not found"
        };

        public static ErrorResponse InternalError { get; } = new()
        {
            errorCode = "HB50001",
            message = "Internal server error"
        };

        public static ErrorResponse ValidationError(string message) => new()
        {
            errorCode = "HB40001",
            message = message
        };
    }
}
