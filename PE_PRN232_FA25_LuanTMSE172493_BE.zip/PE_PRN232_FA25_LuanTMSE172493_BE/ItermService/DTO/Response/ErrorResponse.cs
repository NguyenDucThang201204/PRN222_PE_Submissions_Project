﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItermService.DTO.Response
{
    public class ErrorResponse
    {
        public string errorCode { get; set; }
        public string message { get; set; }
    }
}
