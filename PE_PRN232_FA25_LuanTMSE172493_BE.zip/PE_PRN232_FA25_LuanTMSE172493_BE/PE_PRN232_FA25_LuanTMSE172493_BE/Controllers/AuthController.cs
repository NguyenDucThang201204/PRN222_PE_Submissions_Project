﻿using ItermService;
using ItermService.DTO.Request;
using ItermService.DTO.Response;
using Microsoft.AspNetCore.Mvc;

namespace PE_PRN232_FA25_LuanTMSE172493_BE.Controllers
{
    [ApiController]
    [Route("Accounts")]
    public class AuthController : ControllerBase
    {
        private readonly IBearAccountService _bearAccountService;

        public AuthController(IBearAccountService systemAccountService)
        {
            _bearAccountService = systemAccountService;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto loginRequest)
        {
            if (string.IsNullOrEmpty(loginRequest.userName))
            {
                return BadRequest(ApiErrorResponses.ValidationError("Missing/invalid input"));
            }
            else if (string.IsNullOrEmpty(loginRequest.password))
            {
                return BadRequest(ApiErrorResponses.ValidationError("Missing/invalid input"));
            }


            var loginResponse = await _bearAccountService.LoginAsync(loginRequest);
            if (loginResponse == null)
            {
                return Unauthorized(ApiErrorResponses.Unauthorized);
            }
            return Ok(loginResponse);
        }
    }
}
