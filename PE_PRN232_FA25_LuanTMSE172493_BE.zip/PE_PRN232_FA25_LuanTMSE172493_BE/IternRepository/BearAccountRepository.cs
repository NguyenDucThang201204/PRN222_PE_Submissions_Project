﻿using IternRepository.GenericRepository;
using IternRepository.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IternRepository
{
    public class BearAccountRepository : GenericRepository<BearAccount>, IBearAccountRepository
    {
        public BearAccountRepository(FA25BearDBContext context) : base(context)
        {
        }
        public async Task<BearAccount?> GetByEmailAsync(string userName)
        {
            return await _context.BearAccounts
                                 .FirstOrDefaultAsync(a => a.UserName == userName);
        }
    }
}
