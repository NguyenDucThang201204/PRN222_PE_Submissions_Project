﻿using IternRepository.GenericRepository;
using IternRepository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IternRepository
{
    public interface IBearAccountRepository : IGenericRepository<BearAccount>
    {
        Task<BearAccount?> GetByEmailAsync(string email);
    }
}
