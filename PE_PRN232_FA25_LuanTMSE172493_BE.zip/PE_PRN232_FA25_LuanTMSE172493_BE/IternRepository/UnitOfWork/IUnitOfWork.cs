﻿using IternRepository.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IternRepository.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {      
        IBearAccountRepository Accounts { get; }    
        Task<int> SaveChangesAsync();
    }
}
