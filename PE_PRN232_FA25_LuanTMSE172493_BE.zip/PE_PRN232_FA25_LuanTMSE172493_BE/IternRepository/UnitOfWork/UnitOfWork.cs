﻿using IternRepository.GenericRepository;
using IternRepository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IternRepository.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly FA25BearDBContext _context;      
        public IBearAccountRepository Accounts { get; }
    
        public UnitOfWork(
            FA25BearDBContext context,         
            IBearAccountRepository accountRepository)       
        {
            _context = context;         
            Accounts = accountRepository;        
        }

        public Task<int> SaveChangesAsync()
        {
            return _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
