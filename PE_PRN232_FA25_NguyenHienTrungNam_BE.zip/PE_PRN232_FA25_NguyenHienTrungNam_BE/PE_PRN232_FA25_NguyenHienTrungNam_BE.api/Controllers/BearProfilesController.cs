﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Repositories.Models;
using Services;
using Services.Dtos;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace PE_PRN232_FA25_NguyenHienTrungNam_BE.api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BearProfilesController : ControllerBase
    {

        private readonly BearProfileService _profileService;
        private readonly BearTypeService _typeService;

        public BearProfilesController(BearProfileService profileService, BearTypeService typeService)
        {
            _profileService = profileService;
            _typeService = typeService;
        }

        [HttpGet]
        [Authorize(Roles = "1,2")]
        public async Task<IEnumerable<BearProfile>> Get()
        {
            return await _profileService.GetAllProfilesAsync();
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "1,2")]
        public async Task<IActionResult> Get(int id)
        {
            var profile = await _profileService.GetProfileByIdAsync(id);

            if (profile == null)
            {
                return NotFound("profile not found");
            }

            return Ok(profile);
        }

        [HttpPost("search")]
        [Authorize(Roles = "1,2,3,4")]
        public async Task<IActionResult> Search([FromBody] SearchRequest request)
        {
            try
            {
                var items = await _profileService.SearchAsync(request);
                if (items.Items.IsNullOrEmpty())
                {
                    return NotFound("No profiles found");
                }

                return Ok(items);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        

        [HttpPut("{id}")]
        [Authorize(Roles = "1,2")]
        public async Task<IActionResult> Put(int id, [FromBody] ProfileRequest request)
        {
            if (!ModelState.IsValid)
            {
                var error = ModelState.Values.SelectMany(v => v.Errors).FirstOrDefault()?.ErrorMessage ?? "Invalid input";
                return BadRequest(error);
            }

            var existing = await _profileService.GetProfileByIdAsync(id);
            if (existing == null)
            {
                return NotFound("Profile not found");
            }

            var type = await _typeService.GetByIdAsync(request.BearTypeId);
            if (type == null)
            {
                return BadRequest("Type does not exist");
            }

            existing.BearTypeId = request.BearTypeId;
            existing.BearName = request.BearName;
            existing.BearWeight = request.BearWeight;
            existing.Characteristics = request.Characteristics;
            existing.CareNeeds = request.CareNeeds;
            existing.ModifiedDate = request.ModifiedDate;

            var checkPut = await _profileService.UpdateProfileAsync(existing);
            if (checkPut == 0)
            {
                return BadRequest("Failed to update Profile.");
            }

            return Ok("Profile updated successfully.");
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "1,2")]
        public async Task<IActionResult> Delete(int id)
        {
            var profile = await _profileService.GetProfileByIdAsync(id);
            if (profile == null)
            {
                return NotFound("Profile not found");
            }
            var checkDel = await _profileService.DeleteProfileAsync(id);
            if (!checkDel)
            {
                return BadRequest("Failed to delete Profile.");
            }
            return Ok("Profile deleted successfully.");
        }

        public class ProfileRequest 
        {
            [Required]
            public int BearTypeId { get; set; }
            [Required]
            [RegularExpression(@"^([A-Z0-9][a-zA-Z0-9#]*\s)*([A-Z0-9][a-zA-Z0-9#]*)$")]
            [DefaultValue("BrownBear")]
            public string BearName { get; set; }
            [Required]
            [Range(200, double.MaxValue)]
            public double BearWeight { get; set; }
            [Required]
            public string Characteristics { get; set; }
            [Required]
            public string CareNeeds { get; set; }
            [Required]
            public DateTime ModifiedDate { get; set; }
        }

    }
}
