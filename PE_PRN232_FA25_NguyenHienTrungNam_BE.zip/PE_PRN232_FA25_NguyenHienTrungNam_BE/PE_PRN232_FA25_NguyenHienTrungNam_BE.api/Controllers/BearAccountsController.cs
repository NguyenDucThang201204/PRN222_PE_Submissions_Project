﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Repositories.Models;
using Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace PE_PRN232_FA25_NguyenHienTrungNam_BE.api.Controllers
{
    [Route("api/Accounts")]
    [ApiController]
    public class BearAccountsController : ControllerBase
    {


        private readonly IConfiguration _config;
        private readonly BearAccountService _userAccountsService;

        public BearAccountsController(IConfiguration config, BearAccountService userAccountsService)
        {
            _config = config;
            _userAccountsService = userAccountsService;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.username) || string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest(new { Message = "username and password are required" });
            }

            var user = await _userAccountsService.GetUserAccount(request.username, request.Password);

            if (user == null)
            {
                return Unauthorized(new { Message = "Invalid username or password" });
            }

            var token = GenerateJSONWebToken(user);
            if (token == string.Empty)
            {
                return StatusCode(StatusCodes.Status403Forbidden, "Access denied for this role");
            }

            return Ok(new LoginResponse { Token = token, Role = user.RoleId });
        }

        private string GenerateJSONWebToken(BearAccount account)
        {

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                                             _config["Jwt:Audience"],
                                             new[]
                                             {
                                             new Claim(ClaimTypes.Email, account.Email),
                                             new Claim(ClaimTypes.Role, account.RoleId.ToString())
                                             },
                                             expires: DateTime.Now.AddDays(14),
                                             signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public sealed record LoginRequest(string username, string Password);

        public class LoginResponse
        {
            public string Token { get; set; }
            public int Role { get; set; }
        }

    }
}
