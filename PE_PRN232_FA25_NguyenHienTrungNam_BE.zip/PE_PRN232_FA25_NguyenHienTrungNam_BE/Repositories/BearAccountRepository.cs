﻿using Microsoft.EntityFrameworkCore;
using Repositories.Basic;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class BearAccountRepository : GenericRepository<BearAccount>
    {


        public BearAccountRepository() { }

        public BearAccountRepository(FA25BearDBContext context) => _context = context;

        public async Task<BearAccount?> GetUserAccount(string username, string password)
        {
            return await _context.BearAccounts.FirstOrDefaultAsync(u => u.Email == username && u.Password == password);
        }

    }
}
