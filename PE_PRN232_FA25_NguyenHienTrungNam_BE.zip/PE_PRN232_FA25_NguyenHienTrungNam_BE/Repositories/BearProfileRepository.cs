﻿using Microsoft.EntityFrameworkCore;
using Repositories.Basic;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class BearProfileRepository : GenericRepository<BearProfile>
    {


        public BearProfileRepository(FA25BearDBContext context)
        {
            _context = context;
        }

        public async Task<List<BearProfile>> GetAllAsync()
        {
            return await _context.BearProfiles
                .Include(b => b.BearType)
                .OrderByDescending(b => b.BearProfileId)
                .ToListAsync();
        }

        public async Task<BearProfile?> GetByIdAsync(int id)
        {
            return await _context.BearProfiles
                .Include(b => b.BearType)
                .FirstOrDefaultAsync(lp => lp.BearProfileId == id);
        }

        public async Task<List<BearProfile>> SearchAsync(string? bearName, double? bearWeight, string? bearTypeName)
        {
            var items = await _context.BearProfiles
                .Include(h => h.BearType)
                .Where(s =>
                    (s.BearName.Contains(bearName) || string.IsNullOrEmpty(bearName)) &&
                    (!bearWeight.HasValue || s.BearWeight == bearWeight.Value || bearWeight == 0 ) &&
                    (s.BearType.BearTypeName.Contains(bearTypeName) || string.IsNullOrEmpty(bearTypeName)))
                .OrderByDescending(h => h.BearProfileId)
                .ToListAsync();

            return items ?? new List<BearProfile>();
        }

    }
}
