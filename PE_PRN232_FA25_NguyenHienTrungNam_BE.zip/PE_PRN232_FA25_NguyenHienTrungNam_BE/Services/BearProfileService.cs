﻿using Repositories;
using Repositories.Models;
using Services.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class BearProfileService
    {

        private readonly BearProfileRepository _repository;

        public BearProfileService(BearProfileRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<BearProfile>> GetAllProfilesAsync()
        {
            try
            {
                return await _repository.GetAllAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<BearProfile?> GetProfileByIdAsync(int id)
        {
            try
            {
                return await _repository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<int> CreateProfileAsync(BearProfile profile)
        {
            try
            {
                return await _repository.CreateAsync(profile);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<int> UpdateProfileAsync(BearProfile profile)
        {
            try
            {
                return await _repository.UpdateAsync(profile);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<bool> DeleteProfileAsync(int id)
        {
            try
            {
                var profile = await _repository.GetByIdAsync(id);
                return await _repository.RemoveAsync(profile);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<PaginationResult<BearProfile>> SearchAsync(SearchRequest request)
        {
            try
            {
                var query = await _repository.SearchAsync(request.BearName, request.BearWeight, request.BearTypeName);
                var totalItems = query.Count;
                var items = query
                    .Skip((request.CurrentPage - 1) * request.PageSize)
                    .Take(request.PageSize)
                    .ToList();

                return new PaginationResult<BearProfile>
                {
                    Items = items,
                    TotalItems = totalItems,
                    CurrentPage = request.CurrentPage,
                    PageSize = request.PageSize
                };
            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}
