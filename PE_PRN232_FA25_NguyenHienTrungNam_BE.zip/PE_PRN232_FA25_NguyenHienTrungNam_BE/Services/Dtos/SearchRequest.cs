﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Dtos
{
    public class SearchRequest
    {
        public int CurrentPage { get; set; } = 2;
        public int PageSize { get; set; } = 3;
        public string? BearName { get; set; }
        public double? BearWeight { get; set; }
        public string? BearTypeName { get; set; }
    }
}
