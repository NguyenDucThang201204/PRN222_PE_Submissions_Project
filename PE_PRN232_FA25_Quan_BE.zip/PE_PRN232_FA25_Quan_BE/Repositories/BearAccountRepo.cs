﻿using Microsoft.EntityFrameworkCore;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class BearAccountRepo
    {
        private readonly FA25BearDBContext _context;
        public BearAccountRepo(FA25BearDBContext context)
        {
            _context = context;
        }

        public async Task<BearAccount> GetAccount(string email, string password)
        {
            return await _context.BearAccounts.FirstOrDefaultAsync(u => u.Email == email && u.Password == password);
        }
    }
}
