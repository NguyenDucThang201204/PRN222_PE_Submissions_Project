﻿using Microsoft.EntityFrameworkCore;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class BearProfileRepo
    {
        private FA25BearDBContext _context;

        public BearProfileRepo(FA25BearDBContext context)
        {
            _context = context;
        }

        public async Task<List<BearProfile>> GetAllAsync()
        {
            var items = await _context.BearProfiles.Include(c => c.BearType).ToListAsync();

            return items ?? new List<BearProfile>();
        }

        public async Task<BearProfile?> GetByIdAsync(int code)
        {
            var item = await _context.BearProfiles
                .Include(c => c.BearType)
                .FirstOrDefaultAsync(c => c.BearProfileId == code);
            return item;
        }

        //public async Task<List<BearProfile>> SearchAsync(string? modelName, string? material)
        //{
        //    var query = _context.Handbags
        //        .Include(c => c.Brand)
        //        .AsQueryable();

        //    if (!string.IsNullOrEmpty(modelName))
        //    {
        //        query = query.Where(c => c.ModelName.Contains(modelName));
        //    }

        //    if (!string.IsNullOrEmpty(material))
        //    {
        //        query = query.Where(c => c.Material.Contains(material));
        //    }

        //    //if (!string.IsNullOrEmpty(name))
        //    //{
        //    //    query = query.Where(c => c.ReturnCondition != null && c.ReturnCondition.Name.Contains(name));
        //    //}
        //    //if (cost > 0)
        //    //{
        //    //    query = query.Where(c => c.TotalCost == cost);
        //    //}

        //    var items = await query
        //        .OrderByDescending(c => c.ReleaseDate)
        //        .ToListAsync();

        //    return items ?? new List<Handbag>();
        //}

        public async Task CreateAsync(BearProfile entity)
        {
            _context.BearProfiles.Add(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(BearProfile entity)
        {
            _context.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var entity = _context.BearProfiles.FirstOrDefault(h => h.BearProfileId == id);
            if (entity != null)
            {
                _context.BearProfiles.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}
