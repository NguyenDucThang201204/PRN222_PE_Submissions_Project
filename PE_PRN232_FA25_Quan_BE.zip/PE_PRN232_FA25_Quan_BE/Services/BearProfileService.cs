﻿using Repositories;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class BearProfileService
    {
        private readonly BearProfileRepo _repo;
        public BearProfileService(BearProfileRepo repo)
        {
            _repo = repo;
        }

        public async Task<List<BearProfile>> GetAllAsync()
        {
            return await _repo.GetAllAsync();
        }

        public async Task<BearProfile> GetByIdAsync(int id)
        {
            return await _repo.GetByIdAsync(id);
        }
        //public async Task<List<BearProfile>> SearchAsync(string? modelName, string? material)
        //{
        //    return await _repo.SearchAsync(modelName, material);
        //}
        public async Task CreateAsync(BearProfile entity)
        {
            await _repo.CreateAsync(entity);
        }

        public async Task UpdateAsync(BearProfile entity)
        {
            await _repo.UpdateAsync(entity);
        }

        public async Task DeleteAsync(int id)
        {
            await _repo.DeleteAsync(id);
        }
    }
}
