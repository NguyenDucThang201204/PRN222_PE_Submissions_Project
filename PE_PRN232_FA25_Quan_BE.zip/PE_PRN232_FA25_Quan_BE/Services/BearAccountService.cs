﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Repositories;
using Repositories.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class BearAccountService
    {
        private readonly BearAccountRepo _repo;
        private readonly IConfiguration _config;
        public BearAccountService(BearAccountRepo repo, IConfiguration config)
        {
            _repo = repo;
            _config = config;
        }

        public async Task<AuthResult> GetAccount(string email, string password)
        {
            var account = await _repo.GetAccount(email, password);
            string token = null;
            if (account != null)
            {
                string accountRole;
                if (account.RoleId == 1)
                {
                    accountRole = "Admin";
                    token = GenerateJSONWebToken(account);
                }
                else if (account.RoleId == 2)
                {
                    accountRole = "Manager";
                    token = GenerateJSONWebToken(account);
                }
                else if (account.RoleId == 3)
                {
                    accountRole = "Staff";
                    token = GenerateJSONWebToken(account);
                }
                else if (account.RoleId == 4)
                {
                    accountRole = "Member";
                    token = GenerateJSONWebToken(account);
                }
                else
                {
                    accountRole = null;
                }
                return new AuthResult
                {
                    accessToken = token,
                    roleName = accountRole
                };
            }
            else
            {
                return null;
            }

        }

        public string GenerateJSONWebToken(BearAccount account)
        {

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_config["Jwt:Issuer"]
                    , _config["Jwt:Audience"]
                    , new Claim[]
                    {
                    new(ClaimTypes.Email, account.Email),
                    new(ClaimTypes.Role, account.RoleId.ToString()),
                    },
                    expires: DateTime.Now.AddMinutes(120),
                    signingCredentials: credentials
                );

            var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

            return tokenString;
        }

        public class AuthResult
        {
            public string accessToken { get; set; }
            public string roleName { get; set; }
        }
    }
}
