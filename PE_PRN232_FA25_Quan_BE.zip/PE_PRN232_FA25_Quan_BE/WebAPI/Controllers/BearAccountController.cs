﻿using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Services;
using WebAPI.DTOs;

namespace WebAPI.Controllers
{
    [Route("Accounts/")]
    [ApiController]
    public class BearAccountController : ControllerBase
    {
        private readonly BearAccountService _service;
        public BearAccountController(BearAccountService service)
        {
            _service = service;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login(DTOs.LoginRequest loginRequest)
        {
            var result = await _service.GetAccount(loginRequest.email, loginRequest.password);
            if (result == null)
            {
                return Unauthorized(new ErrorResponse
                {
                    errorCode = "400",
                    message = "Invalid email or password."
                });
            }
            return Ok(new LoginResponse
            {
                token = result.accessToken,
                role = result.roleName
            });
        }
    }
}
