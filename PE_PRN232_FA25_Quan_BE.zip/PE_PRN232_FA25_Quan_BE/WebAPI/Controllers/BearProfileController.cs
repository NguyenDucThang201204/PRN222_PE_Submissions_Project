﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Repositories.Models;
using Services;
using WebAPI.DTOs;

namespace WebAPI.Controllers
{
    //[Route("api/")]
    [ApiController]
    public class BearProfileController : ControllerBase
    {
        private readonly BearProfileService _service;
        public BearProfileController(BearProfileService service)
        {
            _service = service;
        }   

        [Authorize(Roles = "1,2")]
        [HttpGet("BearProfiles")]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                var result = await _service.GetAllAsync();
                return Ok(result);
            }
            catch
            {
                return StatusCode(500, new ErrorResponse { errorCode = "500", message = "Internal server error" });
            }
        }

        //[Authorize(Roles = "3,4")]
        //[HttpGet("BearProfiles/Search")]
        //public async Task<IActionResult> SearchAsync([FromQuery] string? modelName, [FromQuery] string? material)
        //{
        //    try
        //    {
        //        var list = await _service.SearchAsync(modelName, material);

        //        if (list == null || list.Count == 0)
        //        {
        //            return Ok(new List<HandbagSearchResponse>());
        //        }

        //        var grouped = list
        //            .GroupBy(h => h.Brand?.BrandName ?? "Unknown")
        //            .Select(g => new HandbagSearchResponse
        //            {
        //                BrandName = g.Key,
        //                Handbags = g.Select(h => new HandbagDetail
        //                {
        //                    HandbagId = h.HandbagId,
        //                    ModelName = h.ModelName,
        //                    Material = h.Material,
        //                    Color = h.Color,
        //                    Price = h.Price,
        //                    Stock = h.Stock,
        //                    ReleaseDate = h.ReleaseDate
        //                }).ToList()
        //            })
        //            .ToList();

        //        return Ok(grouped);
        //    }
        //    catch
        //    {
        //        return StatusCode(500, new ErrorResponse { errorCode = "HB50001", message = "Internal server error" });
        //    }
        //}

        [Authorize(Roles = "1,2")]
        [HttpGet("BearProfiles/{id}")]
        public async Task<IActionResult> GetByIdAsync(int id)
        {
            try
            {
                var response = await _service.GetByIdAsync(id);
                if (response == null)
                {
                    return NotFound(new ErrorResponse
                    {
                        errorCode = "400",
                        message = "Bear not found."
                    });
                }
                else
                {
                    return Ok(response);
                }
            }
            catch
            {
                return StatusCode(500, new ErrorResponse { errorCode = "500", message = "Internal server error" });
            }
        }

        [Authorize(Roles = "1,2")]
        [HttpPost("BearProfiles")]
        public async Task<IActionResult> CreateAsync([FromBody] BearProfileRequest request)
        {
            if (request == null)
            {
                return BadRequest();
            }

            var entity = new BearProfile
            {
                BearProfileId = request.BearProfileId,
                BearTypeId = request.BearTypeId,
                BearName = request.BearName,
                BearWeight = request.BearWeight,
                Characteristics = request.Characteristics,
                CareNeeds = request.CareNeeds,
                ModifiedDate = request.ModifiedDate
            };

            await _service.CreateAsync(entity);
            return Ok(new { message = "BearProfile added successfully." });
        }

        [Authorize(Roles = "1,2")]
        [HttpPut("BearProfiles/{id}")]
        public async Task<IActionResult> UpdateAsync(int id, [FromBody] BearProfileUpdateRequest request)
        {
            if (request == null)
            {
                return BadRequest();
            }

            var existing = await _service.GetByIdAsync(id);
            if (existing == null)
            {
                return NotFound();
            }

            existing.BearTypeId = request.BearTypeId;
            existing.BearName = request.BearName;
            existing.BearWeight = request.BearWeight;
            existing.Characteristics = request.Characteristics;
            existing.CareNeeds = request.CareNeeds;
            existing.ModifiedDate = request.ModifiedDate;

            await _service.UpdateAsync(existing);
            return Ok(new { message = "Handbag updated successfully." });
        }

        [Authorize(Roles = "1,2")]
        [HttpDelete("BearProfiles/{id}")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            var existing = await _service.GetByIdAsync(id);
            if (existing == null)
            {
                return NotFound();
            }

            await _service.DeleteAsync(id);
            return Ok(new { message = "BearProfile deleted successfully." });
        }
    }
}
