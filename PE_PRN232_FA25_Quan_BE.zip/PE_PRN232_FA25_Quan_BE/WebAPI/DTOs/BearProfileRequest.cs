﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI.DTOs
{
    public class BearProfileRequest
    {
        [Required]
        public int BearProfileId { get; set; }
        [Required]
        public int? BearTypeId { get; set; }

        [RegularExpression(
@"^([A-Z0-9][a-zA-Z0-9#]*\s)*([A-Z0-9][a-zA-Z0-9#]*)$",
ErrorMessage = "Invalid BearName")]
        [Required]
        public string BearName { get; set; }

        [Range(200, int.MaxValue, ErrorMessage = "Invalid BearWeight")]
        [Required]
        public int? BearWeight { get; set; }
        [Required]
        public string Characteristics { get; set; }
        [Required]
        public string CareNeeds { get; set; }
        [Required]
        public DateTime? ModifiedDate { get; set; }
    }
}
