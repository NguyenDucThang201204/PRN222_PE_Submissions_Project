﻿namespace WebAPI.DTOs
{
    public class ErrorResponse
    {
            public string errorCode { get; set; }
            public string message { get; set; }

    }
}
