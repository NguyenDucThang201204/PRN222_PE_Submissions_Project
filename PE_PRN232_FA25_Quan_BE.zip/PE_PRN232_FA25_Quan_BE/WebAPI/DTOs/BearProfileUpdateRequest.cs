﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI.DTOs
{
    public class BearProfileUpdateRequest
    {
        [Required]
        public int? BearTypeId { get; set; }
        [Required]
        [RegularExpression(
@"^([A-Z0-9][a-zA-Z0-9#]*\s)*([A-Z0-9][a-zA-Z0-9#]*)$",
ErrorMessage = "Invalid BearName")]
        public string BearName { get; set; }
        [Required]
        [Range(200, int.MaxValue, ErrorMessage = "Invalid BearWeight")]
        public int? BearWeight { get; set; }
        [Required]
        public string Characteristics { get; set; }
        [Required]
        public string CareNeeds { get; set; }
        [Required]
        public DateTime? ModifiedDate { get; set; }
    }
}
