﻿using BusinessLogicLayer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PE_PRN232_FA25_TranVanLam_BE.Contracts;
using PE_PRN232_FA25_TranVanLam_BE.Services;

namespace PE_PRN232_FA25_TranVanLam_BE.Controllers
{
    [Route("api/login")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _service;
        private readonly TokenService _token;

        public AuthController(AuthService service, TokenService token)
        {
            _service = service;
            _token = token;
        }

        // POST /api/auth
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult<LoginResponse>> Post([FromBody] LoginRequest req)
        {
            if (req == null || string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password))
                return BadRequest();

            var data = await _service.Search(req.Username, req.Password);
            if (data == null) return Unauthorized();

            if (!_service.ValidateRole(data.RoleId)) return Unauthorized();

            var roleName = _service.MapRoleName(data.RoleId);
            var jwt = _token.Generate(data, roleName);

            return Ok(new LoginResponse { Token = jwt, Role = roleName });
        }
    }
}
