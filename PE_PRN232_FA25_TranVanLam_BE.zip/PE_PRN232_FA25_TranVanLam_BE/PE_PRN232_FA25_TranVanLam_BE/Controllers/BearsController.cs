﻿using BusinessLogicLayer;
using DataAccessLayer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PE_PRN232_FA25_TranVanLam_BE.Controllers
{
    [Route("api/BearProfiles")]
    [ApiController]
    public class BearsController : ControllerBase
    {
        private readonly BearServices _service;
        public BearsController(BearServices service) => _service = service;

        
        [HttpGet]
        [Authorize(Roles = "manager,member,staff")]
        public async Task<ActionResult<List<BearProfile>>> Get()
        {
             var items = await _service.GetAllAsync();
             return Ok(items);
        }

        [HttpGet("{id:int}")]
        [Authorize(Roles = "manager,member,staff")]
        public async Task<ActionResult<BearProfile>> GetByID(int id)
        {
            var item = await _service.GetByIdAsync(id);
            if (item == null) return NotFound();
            return Ok(item);
        }

        [HttpDelete("{id:int}")]
        [Authorize(Roles = "manager")]
        public async Task<IActionResult> Delete(int id)
        {
            var (ok, error) = await _service.DeleteAsync(id);
            if (!ok)
            {
                return error switch
                {
                    "not_found" => NotFound(),
                    _ => StatusCode(500, new { message = "delete failed" })
                };
            }
            return NoContent();
        }


    }
}
