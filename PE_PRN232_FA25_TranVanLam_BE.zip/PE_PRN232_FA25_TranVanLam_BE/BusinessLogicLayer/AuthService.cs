﻿using DataAccessLayer;
using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class AuthService
    {
        private readonly IAuthRepository _data;
        public AuthService(IAuthRepository data) => _data = data;

        public async Task<BearAccount?> Search(string username, string password)
            => await _data.GetAccount(username, password);

        public bool ValidateRole(int? role) => role is 1 or 2 or 3 or 4;

        public string MapRoleName(int? role) => role switch
        {
            1 => "admin",
            2 => "manager",
            3 => "staff",
            4 => "member",
            _ => "unknown"
        };
    }
}
