﻿using DataAccessLayer;
using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class BearServices
    {
        private readonly IBearRepository _data;
        public BearServices(IBearRepository data) => _data = data;

        public async Task<List<BearProfile>> GetAllAsync() => await _data.GetAllAsync();
        public async Task<BearProfile?> GetByIdAsync(int id) => await _data.GetByIdAsync(id);
        public async Task<(bool ok, string? error)> DeleteAsync(int id)
        {
            if (!await _data.ExistsAsync(id)) return (false, "not_found");
            var rows = await _data.DeleteAsync(id);
            return rows > 0 ? (true, null) : (false, "delete_failed");
        }
    }
}
