﻿using System;
using System.Collections.Generic;

namespace DataAccessLayer.Models;

public partial class BearProfile
{
    public int BearProfileId { get; set; }

    public int? BearTypeId { get; set; }

    public string BearName { get; set; } = null!;

    public string? Characteristic { get; set; }

    public string? CareNeeds { get; set; }

    public int? BearWeight { get; set; }

    public DateOnly? ModifiedDate { get; set; }

    public virtual BearType? BearType { get; set; }
}
