﻿using System;
using System.Collections.Generic;

namespace DataAccessLayer.Models;

public partial class BearAccount
{
    public int AccountId { get; set; }

    public string Username { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Password { get; set; } = null!;

    public int? RoleId { get; set; }

    public string? Phone { get; set; }
}
