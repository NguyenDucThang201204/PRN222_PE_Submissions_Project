﻿using DataAccessLayer.DBContext;
using DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public interface IBearRepository
    {
        Task<List<BearProfile>> GetAllAsync();
        Task<BearProfile?> GetByIdAsync(int id);
        Task<int> DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
    }
    public class BearRepository : IBearRepository
    {
        private readonly Fa25bearDbContext _context;
        public BearRepository(Fa25bearDbContext context) => _context = context;

        public async Task<List<BearProfile>> GetAllAsync()
        {
            return await _context.BearProfiles
                .AsNoTracking()
                .Include(x => x.BearType)
                .OrderByDescending(x => x.BearProfileId)
                .ToListAsync();

          

        }

        public async Task<bool> ExistsAsync(int id)
            => await _context.BearProfiles.AsNoTracking().AnyAsync(x => x.BearProfileId == id);

        public async Task<BearProfile?> GetByIdAsync(int id)
        {
            return await _context.BearProfiles
                .AsNoTracking()
                .Include(x => x.BearType)
                .FirstOrDefaultAsync(x => x.BearProfileId == id);
        }

        public async Task<int> DeleteAsync(int id)
        {
            var temp = new BearProfile { BearProfileId = id };
            _context.Entry(temp).State = EntityState.Deleted;
            return await _context.SaveChangesAsync();
        }
    }
}
