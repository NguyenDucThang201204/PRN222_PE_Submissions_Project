﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.ModelExtensions
{
    public class SearchRequest
    {
        public int? CurrentPage { get; set; }
        public int? PageSize { get; set; }

    }

    public class BearSearchRequest : SearchRequest
    {
        public string? Name { get; set; }
        public int? Weight { get; set; }
        public string? TypeName { get; set; }
    }
}
