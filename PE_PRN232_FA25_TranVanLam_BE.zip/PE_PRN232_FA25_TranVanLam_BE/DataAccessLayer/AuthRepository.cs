﻿using DataAccessLayer.DBContext;
using DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public interface IAuthRepository
    {
        Task<BearAccount?> GetAccount(string username, string password);
    }

    public class AuthRepository : IAuthRepository
    {
        private readonly Fa25bearDbContext _context;
        public AuthRepository(Fa25bearDbContext context) => _context = context;

        public async Task<BearAccount?> GetAccount(string username, string password)
        {
            return await _context.BearAccounts
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Username == username && x.Password == password );
        }
    }
}
