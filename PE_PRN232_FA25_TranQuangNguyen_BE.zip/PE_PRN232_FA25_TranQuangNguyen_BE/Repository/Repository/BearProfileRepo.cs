﻿using Microsoft.EntityFrameworkCore;
using Repository.Basic;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Repository
{
    public class BearProfileRepo : GenericRepository<BearProfile>
    {
        public async Task<List<BearProfile>> GetBearProfilesAsync()
        {
            return await _context.BearProfiles.Include(h => h.BearType).ToListAsync();
        }

        public async Task<BearProfile?> GetBearProfileByIdAsync(int id)
        {
            return await _context.BearProfiles
                .Include(h => h.BearType)
                .FirstOrDefaultAsync(h => h.BearProfileId == id);
        }

        public async Task<int?> CreateBearProfileAsync(BearProfile BearProfile)
        {
            return await CreateAsync(BearProfile);
        }

        public async Task<int?> UpdateBearProfileAsync(BearProfile BearProfile)
        {
            return await UpdateAsync(BearProfile);
        }

        public async Task<bool> DeleteBearProfileAsync(BearProfile BearProfile)
        {
            return await RemoveAsync(BearProfile);
        }
    }
}
