﻿using Repository.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.DTO
{
    public class BearProfileDTO
    {
        public int BearProfileId { get; set; }
        public string BearName { get; set; }

        public int? BearWeight { get; set; }

        public string Characterisics { get; set; }

        public string CareNeeds { get; set; }

        public DateOnly? ModifiedDate { get; set; }

        public string? BearType { get; set; }
    }
    public class CreateBearProfileDTO
    {
        [Required(ErrorMessage = "Model Name is required")]
        [RegularExpression(@"^([A-Z0-9][a-zA-Z0-9#]*\s)*([A-Z0-9][a-zA-Z0-9#]*)$",
        ErrorMessage = "Model Name must start with uppercase letter or digit")]
        public string BearName { get; set; } = null!;

        [Range(200, double.MaxValue, ErrorMessage = "Weight must be greater than 200")]
        public int? BearWeight { get; set; }
        public string Characterisics { get; set; }
        public string CareNeeds { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public int? BearTypeId { get; set; }
    }

    public class UpdateBearProfileDTO
    {
        [Required(ErrorMessage = "Model Name is required")]
        [RegularExpression(@"^([A-Z0-9][a-zA-Z0-9#]*\s)*([A-Z0-9][a-zA-Z0-9#]*)$",
        ErrorMessage = "Model Name must start with uppercase letter or digit")]
        public string BearName { get; set; } = null!;

        [Range(200, double.MaxValue, ErrorMessage = "Weight must be greater than 200")]
        public int? BearWeight { get; set; }
        public string Characterisics { get; set; }
        public string CareNeeds { get; set; }
        public DateOnly? ModifiedDate { get; set; }
        public int? BearTypeId { get; set; }
    }
}
