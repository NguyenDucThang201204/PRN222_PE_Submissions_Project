﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Repository.DTO;
using Repository.MetaData;
using Services;

namespace PE_PRN232_FA25_TranQuangNguyen_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private readonly AccountService _service;

        public AccountsController(AccountService service)
        {
            _service = service;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            try
            {
                var response = await _service.Authenticate(request);
                if (response == null)
                {
                    var error = ErrorCodes.GetError(ErrorCodes.HB40001);
                    return StatusCode(error.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40001,
                        Message = error.Message,
                        Details = "Invalid username or password"
                    });
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                var error = ErrorCodes.GetError(ErrorCodes.HB50001);
                return StatusCode(error.StatusCode, new ErrorResponseDTO
                {
                    ErrorCode = ErrorCodes.HB50001,
                    Message = error.Message,
                    Details = ex.Message
                });
            }
        }
    }
}
