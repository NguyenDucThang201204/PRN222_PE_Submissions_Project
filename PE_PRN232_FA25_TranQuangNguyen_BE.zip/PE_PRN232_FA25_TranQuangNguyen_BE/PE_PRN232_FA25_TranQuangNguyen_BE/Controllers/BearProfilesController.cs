﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Repository.DTO;
using Repository.MetaData;
using Services;

namespace PE_PRN232_FA25_TranQuangNguyen_BE.Controllers
{
    [Route("api/BearProfiles")]
    [ApiController]
    public class BearProfileController : ControllerBase
    {
        private readonly BearProfileService _service;

        public BearProfileController(BearProfileService service)
        {
            _service = service;
        }

        [HttpGet]
        [Authorize(Roles = "Admin, Manager, Staff, Member")]
        public async Task<IActionResult> GetAllBearProfiles()
        {
            try
            {
                var BearProfiles = await _service.GetAllBearProfiles();
                return Ok(BearProfiles);
            }
            catch (Exception ex)
            {
                var error = ErrorCodes.GetError(ErrorCodes.HB50001);
                return StatusCode(error.StatusCode, new ErrorResponseDTO
                {
                    ErrorCode = ErrorCodes.HB50001,
                    Message = error.Message,
                    Details = ex.Message
                });
            }
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "Admin, Manager, Staff, Member")]
        public async Task<IActionResult> GetBearProfileById(int id)
        {
            try
            {
                if (id <= 0)
                {
                    var validationError = ErrorCodes.GetError(ErrorCodes.HB40001);
                    return StatusCode(validationError.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40001,
                        Message = validationError.Message,
                        Details = "Invalid BearProfile ID"
                    });
                }

                var BearProfile = await _service.GetBearProfileById(id);
                if (BearProfile == null)
                {
                    var notFoundError = ErrorCodes.GetError(ErrorCodes.HB40401);
                    return StatusCode(notFoundError.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40401,
                        Message = notFoundError.Message,
                        Details = $"BearProfile with ID {id} not found"
                    });
                }
                return Ok(BearProfile);
            }
            catch (Exception ex)
            {
                var error = ErrorCodes.GetError(ErrorCodes.HB50001);
                return StatusCode(error.StatusCode, new ErrorResponseDTO
                {
                    ErrorCode = ErrorCodes.HB50001,
                    Message = error.Message,
                    Details = ex.Message
                });
            }
        }



        [HttpPost]
        [Authorize(Roles = "Admin, Manager")]
        public async Task<IActionResult> CreateBearProfile([FromBody] CreateBearProfileDTO createBearProfileDTO)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var validationError = ErrorCodes.GetError(ErrorCodes.HB40001);
                    return StatusCode(validationError.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40001,
                        Message = validationError.Message,
                        Details = string.Join("; ", ModelState.Values
                            .SelectMany(v => v.Errors)
                            .Select(e => e.ErrorMessage))
                    });
                }

                var newBearProfile = await _service.CreateBearProfile(createBearProfileDTO);
                return Ok(newBearProfile);
            }
            catch (Exception ex)
            {
                var error = ErrorCodes.GetError(ErrorCodes.HB50001);
                return StatusCode(error.StatusCode, new ErrorResponseDTO
                {
                    ErrorCode = ErrorCodes.HB50001,
                    Message = error.Message,
                    Details = ex.Message
                });
            }
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin, Manager")]
        public async Task<IActionResult> UpdateBearProfile(int id, [FromBody] UpdateBearProfileDTO BearProfileDTO)
        {
            try
            {
                if (id <= 0)
                {
                    var validationError = ErrorCodes.GetError(ErrorCodes.HB40001);
                    return StatusCode(validationError.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40001,
                        Message = validationError.Message,
                        Details = "Invalid BearProfile ID"
                    });
                }

                var updatedBearProfile = await _service.UpdateBearProfile(id, BearProfileDTO);
                if (updatedBearProfile == null)
                {
                    var notFoundError = ErrorCodes.GetError(ErrorCodes.HB40401);
                    return StatusCode(notFoundError.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40401,
                        Message = notFoundError.Message,
                        Details = $"BearProfile with ID {id} not found"
                    });
                }
                return Ok(updatedBearProfile);
            }
            catch (Exception ex)
            {
                var error = ErrorCodes.GetError(ErrorCodes.HB50001);
                return StatusCode(error.StatusCode, new ErrorResponseDTO
                {
                    ErrorCode = ErrorCodes.HB50001,
                    Message = error.Message,
                    Details = ex.Message
                });
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin, Manager")]
        public async Task<IActionResult> DeleteBearProfile(int id)
        {
            try
            {
                if (id <= 0)
                {
                    var validationError = ErrorCodes.GetError(ErrorCodes.HB40001);
                    return StatusCode(validationError.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40001,
                        Message = validationError.Message,
                        Details = "Invalid BearProfile ID"
                    });
                }

                var result = await _service.DeleteBearProfile(id);
                if (!result)
                {
                    var notFoundError = ErrorCodes.GetError(ErrorCodes.HB40401);
                    return StatusCode(notFoundError.StatusCode, new ErrorResponseDTO
                    {
                        ErrorCode = ErrorCodes.HB40401,
                        Message = notFoundError.Message,
                        Details = $"BearProfile with ID {id} not found"
                    });
                }
                return Ok(new { message = "BearProfile deleted successfully." });
            }
            catch (Exception ex)
            {
                var error = ErrorCodes.GetError(ErrorCodes.HB50001);
                return StatusCode(error.StatusCode, new ErrorResponseDTO
                {
                    ErrorCode = ErrorCodes.HB50001,
                    Message = error.Message,
                    Details = ex.Message
                });
            }
        }
    }
}
