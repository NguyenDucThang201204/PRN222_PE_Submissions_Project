﻿using Repository.DTO;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class AccountService
    {
        private readonly AccountRepo _accountRepo;
        private readonly TokenProvider _tokenProvider;

        public AccountService(AccountRepo accountRepo, TokenProvider tokenProvider)
        {
            _accountRepo = accountRepo;
            _tokenProvider = tokenProvider;
        }

        public async Task<LoginResponse> Authenticate(LoginRequest request)
        {
            var account = await _accountRepo.GetOne(request.Username, request.Password);
            if (account == null)
            {
                return null;
            }

            var roles = new List<string>();
            string roleName = account.RoleId switch
            {
                1 => "Admin",
                2 => "Manager",
                3 => "Staff",
                4 => "Member",
                _ => "Unknown" // Default to Member if unrecognized
            };

            if (account.RoleId != 0)
            {
                roles.Add(roleName);
            }


            // Generate JWT token using the existing JWT service
            var token = _tokenProvider.GenerateToken(
                account.AccountId.ToString(),
                account.Email ?? string.Empty,
                roles
            );

            // Generate refresh token
            var refreshToken = _tokenProvider.GenerateRefreshToken();

            return new LoginResponse
            {
                Token = token,
                //Role = account.Role != 0 ? account.Role.ToString() : "0"
                Role = roleName
            };
        }
    }
}
