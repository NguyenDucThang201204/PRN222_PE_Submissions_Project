﻿using Repository.DTO;
using Repository.Models;
using Repository.Repository;

namespace Services
{
    public class BearProfileService
    {
        private readonly BearProfileRepo _BearProfileRepo;

        public BearProfileService(BearProfileRepo BearProfileRepo)
        {
            _BearProfileRepo = BearProfileRepo;
        }

        public async Task<List<BearProfileDTO>> GetAllBearProfiles()
        {
            var BearProfiles = await _BearProfileRepo.GetBearProfilesAsync();
            return BearProfiles.Select(h => new BearProfileDTO
            {
                BearProfileId = h.BearProfileId,
                BearName = h.BearName,
                BearWeight = h.BearWeight,
                Characterisics = h.Characterisics,
                CareNeeds = h.CareNeeds,

                ModifiedDate = h.ModifiedDate,
                BearType = h.BearType.BearTypeName,
            }).ToList();
        }
        public async Task<BearProfileDTO?> GetBearProfileById(int id)
        {
            var BearProfile = await _BearProfileRepo.GetBearProfileByIdAsync(id);
            if (BearProfile == null) return null;
            return new BearProfileDTO
            {
                BearProfileId = BearProfile.BearProfileId,
                BearName  = BearProfile.BearName,
                BearWeight = BearProfile.BearWeight,
                Characterisics = BearProfile.Characterisics,
                CareNeeds = BearProfile.CareNeeds,
                ModifiedDate = BearProfile.ModifiedDate,
                BearType = BearProfile.BearType.BearTypeName,
            };
        }
        public async Task<BearProfileDTO> CreateBearProfile(CreateBearProfileDTO createBearProfileDTO)
        {
            var bears = await _BearProfileRepo.GetBearProfilesAsync();
            int nextId = bears.Any() ? bears.Max(h => h.BearProfileId) + 1 : 1;

            var bear = new BearProfile
            {
                BearProfileId = nextId,
                BearName = createBearProfileDTO.BearName,
                BearWeight = createBearProfileDTO.BearWeight,
                Characterisics = createBearProfileDTO.Characterisics,
                CareNeeds = createBearProfileDTO.CareNeeds,
                ModifiedDate = createBearProfileDTO.ModifiedDate,
                BearTypeId = createBearProfileDTO.BearTypeId,
            };
            await _BearProfileRepo.CreateBearProfileAsync(bear);
            return new BearProfileDTO
            {
                BearProfileId = nextId,
                BearName = bear.BearName,
                BearWeight = bear.BearWeight,
                Characterisics = bear.Characterisics,
                CareNeeds = bear.CareNeeds,
                ModifiedDate = bear.ModifiedDate,
                BearType = bear.BearType.BearTypeName,
            };
        }
        public async Task<BearProfileDTO?> UpdateBearProfile(int id, UpdateBearProfileDTO updateBearProfileDTO)
        {
            var BearProfile = await _BearProfileRepo.GetBearProfileByIdAsync(id);
            if (BearProfile == null) return null;
            BearProfile.BearName = updateBearProfileDTO.BearName ?? BearProfile.BearName;
            BearProfile.BearWeight = updateBearProfileDTO.BearWeight ?? BearProfile.BearWeight;
            BearProfile.Characterisics = updateBearProfileDTO.Characterisics ?? BearProfile.Characterisics;
            BearProfile.CareNeeds = updateBearProfileDTO.CareNeeds ?? BearProfile.CareNeeds;
            BearProfile.ModifiedDate = updateBearProfileDTO.ModifiedDate ?? BearProfile.ModifiedDate;
            BearProfile.BearTypeId = updateBearProfileDTO.BearTypeId ?? BearProfile.BearTypeId;
            await _BearProfileRepo.UpdateBearProfileAsync(BearProfile);

            return new BearProfileDTO
            {
                BearProfileId = BearProfile.BearProfileId,
                BearName = BearProfile.BearName,
                BearWeight = BearProfile.BearWeight,
                Characterisics = BearProfile.Characterisics,
                CareNeeds = BearProfile.CareNeeds,
                ModifiedDate = BearProfile.ModifiedDate,
                BearType = BearProfile.BearType?.BearTypeName,
            };
        }
         public async Task<bool> DeleteBearProfile(int id)
        {
            var BearProfile = await _BearProfileRepo.GetBearProfileByIdAsync(id);
            if (BearProfile == null) return false;
            return await _BearProfileRepo.DeleteBearProfileAsync(BearProfile);
        }
    }
}
